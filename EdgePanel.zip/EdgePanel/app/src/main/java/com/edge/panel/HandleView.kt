package com.edge.panel

import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.view.View

object Cfg {
    val DEF = Color.parseColor("#3B404B")
    fun color(p: SharedPreferences) = p.getInt("c", DEF)
    fun w(p: SharedPreferences) = p.getInt("w", 22)
    fun h(p: SharedPreferences) = p.getInt("h", 96)
    fun a(p: SharedPreferences) = p.getInt("a", 70)
    fun floor(c: Int, min: Int): Int {
        val m = maxOf(Color.red(c), Color.green(c), Color.blue(c), 1)
        if (m >= min) return c
        val k = min.toFloat() / m
        return Color.rgb((Color.red(c) * k).toInt(), (Color.green(c) * k).toInt(), (Color.blue(c) * k).toInt())
    }
    fun handle(c: Int) = Color.argb(0xE6, Color.red(c), Color.green(c), Color.blue(c))
    fun shade(c: Int, f: Float) = Color.rgb((Color.red(c) * (1 - f)).toInt(), (Color.green(c) * (1 - f)).toInt(), (Color.blue(c) * (1 - f)).toInt())
    fun mix(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt())
}

class HandleView(c: Context) : View(c) {
    var color = Cfg.handle(Cfg.DEF)
    var open = 70
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ch = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = minOf(w * 0.65f, h / 2f)
        bg.color = color
        c.drawRoundRect(0f, 0f, w + r, h, r, r, bg)
        ch.strokeWidth = w * 0.14f
        val cx = w * 0.5f; val cy = h / 2f
        val s = minOf(w * (0.2f + open / 100f * 0.6f), h / 2f - w * 0.2f); val d = w * 0.2f
        val p = Path().apply { moveTo(cx + d / 2, cy - s); lineTo(cx - d / 2, cy); lineTo(cx + d / 2, cy + s) }
        c.drawPath(p, ch)
    }
}
