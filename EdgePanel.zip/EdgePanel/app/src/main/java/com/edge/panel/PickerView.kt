package com.edge.panel

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*

class AppItem(val pkg: String, val label: String, val icon: Drawable)

class CheckView(c: Context) : View(c) {
    var on = false
    private var t = 0f
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); color = 0x66FFFFFF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; strokeWidth = dp(2) * 1.3f
    }
    fun set(v: Boolean, anim: Boolean) {
        on = v
        if (!anim) { t = if (v) 1f else 0f; invalidate(); return }
        val a = ValueAnimator.ofFloat(t, if (v) 1f else 0f)
        a.duration = 300
        a.interpolator = OvershootInterpolator(2.5f)
        a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
        a.start()
    }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = width / 2f - dp(2)
        cv.drawCircle(cx, cy, r, ring)
        if (t > 0f) {
            fill.color = Cfg.accent(context)
            cv.drawCircle(cx, cy, r * t, fill)
            tick.alpha = (t.coerceIn(0f, 1f) * 255).toInt()
            val p = Path().apply { moveTo(cx - r * 0.42f, cy); lineTo(cx - r * 0.1f, cy + r * 0.32f); lineTo(cx + r * 0.46f, cy - r * 0.3f) }
            cv.drawPath(p, tick)
        }
    }
}

class Row(c: Context) : LinearLayout(c) {
    private val icon = ImageView(c)
    private val label = TextView(c)
    private val check = CheckView(c)
    init {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(8), dp(14), dp(8))
        addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
        label.textSize = 15f; label.setTextColor(Color.WHITE); label.maxLines = 1; label.ellipsize = TextUtils.TruncateAt.END
        addView(label, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(14), 0, dp(8), 0) })
        addView(check, LinearLayout.LayoutParams(dp(26), dp(26)))
    }
    fun bind(a: AppItem, on: Boolean, cb: (Boolean) -> Unit) {
        icon.setImageDrawable(a.icon); label.text = a.label; check.set(on, false)
        setOnClickListener {
            val n = !check.on
            check.set(n, true); cb(n)
            icon.animate().scaleX(1.22f).scaleY(1.22f).setDuration(110).withEndAction {
                icon.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(3f)).start()
            }.start()
        }
    }
}

class AppAdapter(private val c: Context, private val items: List<AppItem>, private val sel: MutableSet<String>) : BaseAdapter() {
    private val shown = HashSet<Int>()
    override fun getCount() = items.size
    override fun getItem(p: Int): Any = items[p]
    override fun getItemId(p: Int) = p.toLong()
    override fun getView(p: Int, v: View?, g: ViewGroup?): View {
        val row = (v as? Row) ?: Row(c)
        val a = items[p]
        row.bind(a, a.pkg in sel) { on ->
            if (on) sel.add(a.pkg) else sel.remove(a.pkg)
            Cfg.p(c).edit().putStringSet("apps", HashSet(sel)).apply()
        }
        row.animate().cancel()
        if (shown.add(p)) {
            row.alpha = 0f; row.translationX = c.dp(36).toFloat()
            row.animate().alpha(1f).translationX(0f).setStartDelay((p % 9) * 35L).setDuration(340)
                .setInterpolator(DecelerateInterpolator(2f)).start()
        } else { row.alpha = 1f; row.translationX = 0f }
        return row
    }
}

class PickerView(c: Context) : LinearLayout(c) {
    val header = LinearLayout(c)
    init {
        orientation = LinearLayout.VERTICAL
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20), dp(14), dp(20), dp(10))
        header.addView(TextView(c).apply { text = "Выбор приложений"; textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        header.addView(TextView(c).apply { text = "Отмеченные появятся в панели"; textSize = 12f; setTextColor(0x99FFFFFF.toInt()) })
        addView(header, LinearLayout.LayoutParams(-1, -2))
        val lv = ListView(c).apply {
            divider = null; dividerHeight = 0; selector = ColorDrawable(0); isVerticalScrollBarEnabled = false
            setPadding(dp(8), 0, dp(8), dp(10)); clipToPadding = false
        }
        addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        val sel = Cfg.p(c).getStringSet("apps", emptySet())!!.toMutableSet()
        Thread {
            val pm = c.packageManager
            val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .filter { it.activityInfo.packageName != c.packageName }
                .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .sortedBy { it.label.lowercase() }
            post { lv.adapter = AppAdapter(c, list, sel) }
        }.start()
    }
}
