package com.edge.panel

import android.animation.ValueAnimator
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*

class EdgeService : Service() {
    private lateinit var wm: WindowManager
    private var handle: HandleView? = null
    private var panel: FrameLayout? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class HandleView(c: Context) : View(c) {
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E63B404B") }
        private val ch = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat()
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        override fun onDraw(c: Canvas) {
            val r = dp(14).toFloat()
            c.drawRoundRect(0f, 0f, width + r, height.toFloat(), r, r, bg)
            val cx = width * 0.5f; val cy = height / 2f; val s = dp(8).toFloat()
            val p = Path().apply { moveTo(cx + s * 0.5f, cy - s); lineTo(cx - s * 0.5f, cy); lineTo(cx + s * 0.5f, cy + s) }
            c.drawPath(p, ch)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("edge", "Edge Panel", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "edge").setContentTitle("Edge Panel работает")
            .setSmallIcon(android.R.drawable.ic_menu_more).build())
        showHandle()
    }

    private fun showHandle() {
        val h = HandleView(this)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val lp = WindowManager.LayoutParams(dp(22), dp(96), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            y = prefs.getInt("y", resources.displayMetrics.heightPixels / 3)
        }
        var downY = 0f; var downX = 0f; var startY = 0; var moved = false
        h.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startY = lp.y; moved = false; v.animate().alpha(0.7f).setDuration(100).start() }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - downY
                    if (Math.abs(dy) > dp(10)) { moved = true; lp.y = (startY + dy).toInt(); wm.updateViewLayout(v, lp) }
                    if (!moved && downX - e.rawX > dp(14)) { moved = true; v.animate().alpha(1f).start(); openPanel() }
                }
                MotionEvent.ACTION_UP -> {
                    v.animate().alpha(1f).setDuration(150).start()
                    if (moved) prefs.edit().putInt("y", lp.y).apply()
                    else openPanel()
                }
                MotionEvent.ACTION_CANCEL -> v.animate().alpha(1f).start()
            }
            true
        }
        wm.addView(h, lp); handle = h; handleLp = lp
        h.translationX = dp(30).toFloat()
        h.animate().translationX(0f).setDuration(350).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun openPanel() {
        if (panel != null) return
        val root = FrameLayout(this)
        root.isFocusableInTouchMode = true
        val dim = ValueAnimator.ofInt(0, 0x66).setDuration(250)
        dim.addUpdateListener { root.setBackgroundColor(Color.argb(it.animatedValue as Int, 0, 0, 0)) }
        root.setOnClickListener { closePanel() }
        root.setOnKeyListener { _, k, e -> if (k == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP) { closePanel(); true } else false }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(10), dp(14), dp(10), dp(14)) }
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            val r = dp(28).toFloat()
            background = GradientDrawable().apply { setColor(Color.parseColor("#F02B2F38")); cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) }
            elevation = dp(12).toFloat(); isClickable = true
            addView(col)
        }
        val pkgs = getSharedPreferences("p", MODE_PRIVATE).getStringSet("apps", emptySet())!!
        val icons = mutableListOf<View>()
        for (p in pkgs) {
            val d = try { packageManager.getApplicationIcon(p) } catch (_: Exception) { continue }
            val iv = ImageView(this).apply { setImageDrawable(d); scaleX = 0f; scaleY = 0f }
            iv.setOnClickListener { closePanel { launch(p) } }
            col.addView(iv, LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(0, dp(7), 0, dp(7)) })
            icons.add(iv)
        }
        if (icons.isEmpty()) col.addView(TextView(this).apply { text = "Пусто\nвыберите\nприложения"; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; textSize = 12f })
        root.addView(sv, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        wm.addView(root, lp); panel = root
        root.requestFocus()
        handle?.animate()?.alpha(0f)?.setDuration(150)?.start()
        sv.translationX = dp(100).toFloat()
        sv.animate().translationX(0f).setDuration(280).setInterpolator(DecelerateInterpolator(2f)).start()
        dim.start()
        icons.forEachIndexed { i, v ->
            v.animate().scaleX(1f).scaleY(1f).setStartDelay(90L + i * 45L).setDuration(300).setInterpolator(OvershootInterpolator(2f)).start()
        }
    }

    private fun closePanel(after: (() -> Unit)? = null) {
        val root = panel ?: return
        panel = null
        val sv = root.getChildAt(0)
        sv.animate().translationX(dp(100).toFloat()).setDuration(200).start()
        ValueAnimator.ofInt(0x66, 0).setDuration(200).apply {
            addUpdateListener { root.setBackgroundColor(Color.argb(it.animatedValue as Int, 0, 0, 0)) }
            start()
        }
        root.postDelayed({
            try { wm.removeView(root) } catch (_: Exception) {}
            handle?.animate()?.alpha(1f)?.setDuration(200)?.start()
            after?.invoke()
        }, 210)
    }

    private fun launch(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.85).toInt(); val h = (dm.heightPixels * 0.6).toInt()
        val l = (dm.widthPixels - w) / 2; val t = dm.heightPixels / 8
        val o = ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, t + h))
        try { ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(o, 5) } catch (_: Throwable) {}
        startActivity(i, o.toBundle())
    }

    override fun onDestroy() {
        try { handle?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
