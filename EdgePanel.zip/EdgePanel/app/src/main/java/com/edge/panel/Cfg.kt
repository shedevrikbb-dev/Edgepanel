package com.edge.panel

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun View.dp(v: Int): Int = context.dp(v)
fun Context.pill(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

fun View.pressAnim() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
        }
        false
    }
}

object Cfg {
    private val defs = mapOf("hue" to 222, "sat" to 20, "val" to 29, "alpha" to 92, "w" to 22, "h" to 96)
    fun p(c: Context): SharedPreferences = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): Int = p(c).getInt(k, defs[k] ?: 0)
    fun reset(c: Context) { val e = p(c).edit(); defs.keys.forEach { e.remove(it) }; e.apply() }
    private fun hsv(c: Context, a: Int) = Color.HSVToColor(a, floatArrayOf(get(c, "hue").toFloat(), get(c, "sat") / 100f, get(c, "val") / 100f))
    fun color(c: Context) = hsv(c, get(c, "alpha") * 255 / 100)
    fun solid(c: Context) = hsv(c, 255)
    fun accent(c: Context) = Color.HSVToColor(floatArrayOf(get(c, "hue").toFloat(), 0.55f, 1f))
}
