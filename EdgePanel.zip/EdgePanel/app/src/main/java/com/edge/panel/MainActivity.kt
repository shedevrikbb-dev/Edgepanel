package com.edge.panel

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val sel = prefs.getStringSet("apps", emptySet())!!.toMutableSet()
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#14161B")); setPadding(dp(16), dp(40), dp(16), dp(16)) }
        val title = TextView(this).apply { text = "Edge Panel"; textSize = 26f; setTextColor(Color.WHITE) }
        val sub = TextView(this).apply { text = "Выберите приложения для панели"; setTextColor(Color.GRAY); setPadding(0, dp(4), 0, dp(12)) }
        val btn = Button(this).apply { text = "Запустить панель"; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#3A4150")) }
        val stop = Button(this).apply { text = "Остановить"; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#2A2E38")) }
        val list = ListView(this)
        list.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup?): View {
                val ri = apps[p]; val pkg = ri.activityInfo.packageName
                val cb = (v as? CheckBox) ?: CheckBox(this@MainActivity).apply {
                    setTextColor(Color.WHITE); compoundDrawablePadding = dp(12); setPadding(dp(8), dp(10), dp(8), dp(10))
                }
                cb.setOnCheckedChangeListener(null)
                cb.text = ri.loadLabel(pm)
                val ic = ri.loadIcon(pm); ic.setBounds(0, 0, dp(40), dp(40))
                cb.setCompoundDrawables(ic, null, null, null)
                cb.isChecked = pkg in sel
                cb.setOnCheckedChangeListener { _, c ->
                    if (c) sel.add(pkg) else sel.remove(pkg)
                    prefs.edit().putStringSet("apps", sel.toSet()).apply()
                }
                return cb
            }
        }
        btn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Разрешите показ поверх других окон", Toast.LENGTH_LONG).show()
            } else startForegroundService(Intent(this, EdgeService::class.java))
        }
        stop.setOnClickListener { stopService(Intent(this, EdgeService::class.java)) }
        listOf(title, sub, btn, stop).forEach { root.addView(it) }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}
