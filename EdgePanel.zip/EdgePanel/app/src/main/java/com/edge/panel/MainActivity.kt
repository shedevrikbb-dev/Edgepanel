package com.edge.panel

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private var cur = 0
    private lateinit var root: FrameLayout
    private lateinit var list: ListView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var preview: HandleView
    private lateinit var previewLp: FrameLayout.LayoutParams
    private val cards = mutableListOf<View>()
    private val seeks = mutableListOf<SeekBar>()
    private val swatches = mutableListOf<Pair<Int, View>>()
    private class H(val card: LinearLayout, val ic: ImageView, val tv: TextView, val cb: CheckBox)

    private fun rr(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun text(s: String, sp: Float, col: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = sp; setTextColor(col); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun View.pressable() {
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(.94f).scaleY(.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    private fun applyTheme(c: Int) {
        val bg = Cfg.shade(c, .55f)
        root.setBackgroundColor(bg)
        window.statusBarColor = bg; window.navigationBarColor = bg
        cards.forEach { it.background = rr(c, 20) }
        val light = Cfg.mix(c, Color.WHITE, .85f)
        startBtn.background = rr(light, 16); startBtn.setTextColor(Cfg.shade(c, .6f))
        stopBtn.background = rr(Cfg.shade(c, .25f), 16)
        seeks.forEach {
            it.progressTintList = ColorStateList.valueOf(light)
            it.thumbTintList = ColorStateList.valueOf(light)
            it.progressBackgroundTintList = ColorStateList.valueOf(Cfg.mix(c, Color.WHITE, .3f))
        }
        for (i in 0 until list.childCount) (list.getChildAt(i).tag as? H)?.card?.background = rr(c, 16)
    }

    private fun updateSwatches() {
        val sel = Cfg.color(prefs)
        swatches.forEach { (col, v) ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(col)
                if (col == sel) setStroke(dp(3), Color.WHITE) else setStroke(dp(1), 0x55FFFFFF)
            }
        }
    }

    private fun pick(col: Int) {
        prefs.edit().putInt("c", col).apply()
        updateSwatches()
        preview.color = Cfg.handle(col); preview.invalidate()
        ValueAnimator.ofObject(ArgbEvaluator(), cur, col).setDuration(350).apply {
            addUpdateListener { cur = it.animatedValue as Int; applyTheme(cur) }
            start()
        }
    }

    private fun slider(title: String, min: Int, max: Int, key: String, def: Int, onChange: (Int) -> Unit): View {
        val tv = text("", 14f)
        val sb = SeekBar(this).apply { this.max = max - min; progress = prefs.getInt(key, def) - min }
        tv.text = "$title: ${sb.progress + min}"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                val v = p + min; tv.text = "$title: $v"
                prefs.edit().putInt(key, v).apply(); onChange(v)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        seeks.add(sb)
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, 0); addView(tv); addView(sb) }
    }

    private fun makeRow(): FrameLayout {
        val ic = ImageView(this)
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setPadding(dp(14), 0, 0, 0) }
        val cb = CheckBox(this).apply { isClickable = false; isFocusable = false }
        val card = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(10), dp(10))
            addView(ic, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(tv, LinearLayout.LayoutParams(0, -2, 1f)); addView(cb)
        }
        return FrameLayout(this).apply { setPadding(0, 0, 0, dp(8)); addView(card); tag = H(card, ic, tv, cb) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cur = Cfg.color(prefs)
        val sel = prefs.getStringSet("apps", emptySet())!!.toMutableSet()
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        root = FrameLayout(this)
        list = ListView(this).apply {
            divider = null; dividerHeight = 0; isVerticalScrollBarEnabled = false
            selector = ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(16), 0, dp(16), dp(24)); clipToPadding = false
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(36), 0, dp(8)) }
        header.addView(text("Edge Panel", 30f, bold = true))
        header.addView(text("Настройте боковую панель", 14f, 0xAAFFFFFF.toInt()).apply { setPadding(0, dp(2), 0, dp(14)) })

        // Предпросмотр
        val pc = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF2B3550.toInt(), 0xFF141824.toInt()))
                .apply { cornerRadius = dp(20).toFloat() }
            clipToOutline = true
        }
        pc.addView(text("Предпросмотр", 13f, 0x66FFFFFF), FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(16) })
        preview = HandleView(this).apply { color = Cfg.handle(cur) }
        previewLp = FrameLayout.LayoutParams(dp(Cfg.w(prefs)), dp(minOf(Cfg.h(prefs), 190)), Gravity.END or Gravity.CENTER_VERTICAL)
        pc.addView(preview, previewLp)
        header.addView(pc, LinearLayout.LayoutParams(-1, dp(200)).apply { bottomMargin = dp(14) })

        // Настройки
        val sc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(18)) }
        sc.addView(text("Цвет", 14f))
        val row = LinearLayout(this).apply { setPadding(0, dp(10), 0, dp(4)) }
        listOf("#3B404B", "#2F6FED", "#8E4DFF", "#E5484D", "#F5A524", "#17B26A", "#E84393", "#12B5CB").forEach { hex ->
            val col = Color.parseColor(hex)
            val v = View(this).apply {
                setOnClickListener {
                    pick(col)
                    it.animate().scaleX(1.3f).scaleY(1.3f).setDuration(120).withEndAction {
                        it.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                    }.start()
                }
            }
            row.addView(v, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(12) })
            swatches.add(col to v)
        }
        sc.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        sc.addView(slider("Ширина", 10, 48, "w", 22) { previewLp.width = dp(it); preview.layoutParams = previewLp })
        sc.addView(slider("Длина", 50, 200, "h", 96) { previewLp.height = dp(minOf(it, 190)); preview.layoutParams = previewLp })
        cards.add(sc)
        header.addView(sc, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        // Кнопки
        startBtn = Button(this).apply { text = "Запустить"; isAllCaps = false; textSize = 16f; stateListAnimator = null; pressable() }
        stopBtn = Button(this).apply { text = "Остановить"; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE); stateListAnimator = null; pressable() }
        startBtn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Разрешите показ поверх других окон", Toast.LENGTH_LONG).show()
            } else startForegroundService(Intent(this, EdgeService::class.java))
        }
        stopBtn.setOnClickListener { stopService(Intent(this, EdgeService::class.java)) }
        header.addView(LinearLayout(this).apply {
            addView(startBtn, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(5) })
            addView(stopBtn, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(5) })
        })
        header.addView(text("Приложения в панели", 18f, bold = true).apply { setPadding(0, dp(22), 0, dp(10)) })

        val seen = HashSet<Int>()
        list.addHeaderView(header, null, false)
        list.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup?): View {
                val ri = apps[p]; val pkg = ri.activityInfo.packageName
                val w = (v as? FrameLayout) ?: makeRow(); val h = w.tag as H
                h.card.background = rr(cur, 16)
                h.tv.text = ri.loadLabel(pm); h.ic.setImageDrawable(ri.loadIcon(pm))
                h.cb.setOnCheckedChangeListener(null); h.cb.isChecked = pkg in sel
                h.cb.buttonTintList = ColorStateList.valueOf(Color.WHITE)
                h.cb.setOnCheckedChangeListener { _, c ->
                    if (c) sel.add(pkg) else sel.remove(pkg)
                    prefs.edit().putStringSet("apps", sel.toSet()).apply()
                    h.card.animate().scaleX(.97f).scaleY(.97f).setDuration(80).withEndAction {
                        h.card.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(3f)).start()
                    }.start()
                }
                h.card.setOnClickListener { h.cb.toggle() }
                w.animate().cancel()
                if (seen.add(p)) {
                    w.alpha = 0f; w.translationY = dp(40).toFloat()
                    w.animate().alpha(1f).translationY(0f).setStartDelay((p % 10) * 35L).setDuration(350)
                        .setInterpolator(DecelerateInterpolator(2f)).start()
                } else { w.alpha = 1f; w.translationY = 0f }
                return w
            }
        }
        root.addView(list, FrameLayout.LayoutParams(-1, -1))
        updateSwatches(); applyTheme(cur)
        for (i in 0 until header.childCount) header.getChildAt(i).let {
            it.alpha = 0f; it.translationY = dp(30).toFloat()
            it.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(420)
                .setInterpolator(DecelerateInterpolator(2f)).start()
        }
        setContentView(root)
    }
}
